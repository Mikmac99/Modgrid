#!/usr/bin/env python3
"""
ModularGrid Price Monitor - Price Analysis Module
------------------------------------------------
This module handles price comparison logic for the ModularGrid Price Monitor.
It includes functions to analyze current listings against historical price data
and identify good deals based on user-defined thresholds.
"""

import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("price_analysis.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("modulargrid_price_analysis")

class PriceAnalyzer:
    """Class to handle price analysis and deal detection."""
    
    def __init__(self, database):
        """
        Initialize the price analyzer.
        
        Args:
            database: ModularGridDatabase instance
        """
        self.db = database
    
    def analyze_listing(self, listing):
        """
        Analyze a single listing to determine if it's a good deal.
        
        Args:
            listing (dict): Listing data
            
        Returns:
            dict: Analysis results including deal status
        """
        module_id = listing.get('module_id')
        if not module_id:
            logger.warning("Cannot analyze listing without module_id")
            return None
        
        # Get module details
        module = self.db.get_module_by_id(module_id)
        if not module:
            logger.warning(f"Module not found for ID: {module_id}")
            return None
        
        # Get average price for this module
        currency = listing.get('currency', 'EUR')
        avg_price = self.db.get_average_price(module_id, currency)
        
        if avg_price <= 0:
            logger.info(f"No price history available for module: {module.get('name')}")
            return None
        
        # Get watchlist entry for this module
        watchlist_entries = self.db.get_watchlist()
        watchlist_entry = next((w for w in watchlist_entries if w.get('module_id') == module_id), None)
        
        if not watchlist_entry:
            logger.debug(f"Module not in watchlist: {module.get('name')}")
            return None
        
        # Calculate percentage below average
        current_price = listing.get('price', 0)
        if current_price <= 0:
            logger.warning(f"Invalid price for listing: {listing.get('listing_id')}")
            return None
        
        percent_below = 100 - (current_price / avg_price * 100)
        price_difference = avg_price - current_price
        
        # Check if this is a good deal based on threshold
        threshold = watchlist_entry.get('price_threshold', 15.0)
        is_deal = percent_below > threshold
        
        # Check max price constraint if set
        max_price = watchlist_entry.get('max_price')
        if max_price and current_price > max_price:
            is_deal = False
        
        # Prepare analysis results
        analysis = {
            'listing_id': listing.get('listing_id'),
            'module_id': module_id,
            'module_name': module.get('name'),
            'manufacturer': module.get('manufacturer'),
            'current_price': current_price,
            'avg_price': avg_price,
            'price_difference': price_difference,
            'percent_below': percent_below,
            'threshold': threshold,
            'is_deal': is_deal,
            'currency': currency,
            'condition': listing.get('condition', ''),
            'seller': listing.get('seller', ''),
            'region': listing.get('region', ''),
            'url': listing.get('url', '')
        }
        
        logger.info(f"Analyzed {module.get('name')}: {percent_below:.1f}% below average, is deal: {is_deal}")
        return analysis
    
    def find_deals(self, listings=None):
        """
        Find good deals among listings.
        
        Args:
            listings (list, optional): List of listings to analyze. If None, gets active listings from DB.
            
        Returns:
            list: List of good deals
        """
        if listings is None:
            # Use database's built-in deal finder
            return self.db.find_deals()
        
        deals = []
        for listing in listings:
            analysis = self.analyze_listing(listing)
            if analysis and analysis.get('is_deal'):
                deals.append(analysis)
                
                # Record the deal in the database
                deal_data = {
                    'listing_id': analysis.get('listing_id'),
                    'avg_price': analysis.get('avg_price'),
                    'price_difference': analysis.get('price_difference'),
                    'percentage_below': analysis.get('percent_below')
                }
                self.db.add_deal(deal_data)
        
        # Sort deals by percentage below average (best deals first)
        deals.sort(key=lambda x: x.get('percent_below', 0), reverse=True)
        
        logger.info(f"Found {len(deals)} good deals among {len(listings) if listings else 'all'} listings")
        return deals
    
    def analyze_price_trends(self, module_id, days=90):
        """
        Analyze price trends for a module over time.
        
        Args:
            module_id (str): Module ID
            days (int): Number of days to analyze
            
        Returns:
            dict: Price trend analysis
        """
        # This would require more complex time-series analysis
        # For now, we'll just return a simple average and trend direction
        try:
            # Get module details
            module = self.db.get_module_by_id(module_id)
            if not module:
                logger.warning(f"Module not found for ID: {module_id}")
                return None
            
            # Get price history
            self.db.cursor.execute(
                """
                SELECT price, currency, date_sold 
                FROM PriceHistory 
                WHERE module_id = ? 
                ORDER BY date_sold DESC
                """,
                (module_id,)
            )
            history = self.db.cursor.fetchall()
            
            if not history:
                logger.info(f"No price history available for module: {module.get('name')}")
                return {
                    'module_id': module_id,
                    'module_name': module.get('name'),
                    'avg_price': 0,
                    'trend': 'unknown',
                    'data_points': 0
                }
            
            # Convert to list of dicts
            history = [dict(row) for row in history]
            
            # Calculate average price
            prices = [h.get('price', 0) for h in history]
            avg_price = sum(prices) / len(prices) if prices else 0
            
            # Determine trend (simple version)
            trend = 'stable'
            if len(prices) >= 3:
                recent = sum(prices[:3]) / 3
                older = sum(prices[-3:]) / 3 if len(prices) >= 6 else avg_price
                
                if recent < older * 0.95:  # 5% decrease
                    trend = 'decreasing'
                elif recent > older * 1.05:  # 5% increase
                    trend = 'increasing'
            
            return {
                'module_id': module_id,
                'module_name': module.get('name'),
                'avg_price': avg_price,
                'trend': trend,
                'data_points': len(history),
                'currency': history[0].get('currency') if history else 'EUR'
            }
            
        except Exception as e:
            logger.error(f"Error analyzing price trends: {e}")
            return None
    
    def calculate_potential_savings(self, deal):
        """
        Calculate potential savings for a deal.
        
        Args:
            deal (dict): Deal analysis
            
        Returns:
            dict: Savings information
        """
        try:
            current_price = deal.get('current_price', 0)
            avg_price = deal.get('avg_price', 0)
            
            absolute_savings = avg_price - current_price
            percentage_savings = (absolute_savings / avg_price) * 100 if avg_price > 0 else 0
            
            return {
                'absolute': absolute_savings,
                'percentage': percentage_savings,
                'currency': deal.get('currency', 'EUR')
            }
        except Exception as e:
            logger.error(f"Error calculating savings: {e}")
            return {
                'absolute': 0,
                'percentage': 0,
                'currency': deal.get('currency', 'EUR')
            }
    
    def evaluate_condition(self, condition_text):
        """
        Evaluate the condition description to determine quality.
        
        Args:
            condition_text (str): Condition description
            
        Returns:
            str: Condition rating ('excellent', 'good', 'fair', 'poor')
        """
        condition_text = condition_text.lower()
        
        # Keywords indicating excellent condition
        excellent_keywords = [
            'mint', 'new', 'perfect', 'excellent', 'like new', 
            'no scratches', 'no rack rash', 'original box'
        ]
        
        # Keywords indicating good condition
        good_keywords = [
            'good', 'great', 'barely used', 'light use',
            'minor', 'slight', 'small'
        ]
        
        # Keywords indicating fair condition
        fair_keywords = [
            'used', 'normal', 'wear', 'working', 'functional',
            'some', 'few', 'marks'
        ]
        
        # Keywords indicating poor condition
        poor_keywords = [
            'heavy', 'damaged', 'issue', 'problem', 'repair',
            'broken', 'fix', 'not working', 'faulty'
        ]
        
        # Count keyword occurrences
        excellent_count = sum(1 for kw in excellent_keywords if kw in condition_text)
        good_count = sum(1 for kw in good_keywords if kw in condition_text)
        fair_count = sum(1 for kw in fair_keywords if kw in condition_text)
        poor_count = sum(1 for kw in poor_keywords if kw in condition_text)
        
        # Determine condition based on keyword counts
        if poor_count > 0:
            return 'poor'
        elif excellent_count > good_count and excellent_count > fair_count:
            return 'excellent'
        elif good_count > fair_count:
            return 'good'
        elif fair_count > 0:
            return 'fair'
        else:
            return 'unknown'
    
    def adjust_deal_score_by_condition(self, deal):
        """
        Adjust deal score based on condition.
        
        Args:
            deal (dict): Deal analysis
            
        Returns:
            float: Adjusted deal score
        """
        condition_text = deal.get('condition', '')
        condition_rating = self.evaluate_condition(condition_text)
        
        # Base score is percentage below average
        base_score = deal.get('percent_below', 0)
        
        # Adjust score based on condition
        if condition_rating == 'excellent':
            adjusted_score = base_score * 1.2  # 20% bonus for excellent condition
        elif condition_rating == 'good':
            adjusted_score = base_score * 1.0  # No change for good condition
        elif condition_rating == 'fair':
            adjusted_score = base_score * 0.8  # 20% penalty for fair condition
        elif condition_rating == 'poor':
            adjusted_score = base_score * 0.5  # 50% penalty for poor condition
        else:
            adjusted_score = base_score
        
        return adjusted_score

# Example usage
if __name__ == "__main__":
    from modulargrid_database import ModularGridDatabase
    
    # Initialize database and analyzer
    db = ModularGridDatabase("test.db")
    analyzer = PriceAnalyzer(db)
    
    # Example: Analyze a listing
    # listing = {
    #     'listing_id': '12345',
    #     'module_id': '67890',
    #     'price': 200.0,
    #     'currency': 'EUR'
    # }
    # analysis = analyzer.analyze_listing(listing)
    # print(analysis)
    
    # Clean up
    db.close()
